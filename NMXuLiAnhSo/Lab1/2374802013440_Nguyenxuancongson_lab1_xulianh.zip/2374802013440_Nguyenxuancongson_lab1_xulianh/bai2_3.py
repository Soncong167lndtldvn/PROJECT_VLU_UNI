import matplotlib.pylab as plt
import skimage
dt=skimage.io.imread("bird.png", as_gray=True)
plt.imshow(dt,cmap='gray')
plt.show()

#Ảnh trắng đen (grayscale)