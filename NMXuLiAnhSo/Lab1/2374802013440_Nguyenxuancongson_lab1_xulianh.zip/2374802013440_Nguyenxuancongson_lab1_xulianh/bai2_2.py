import imageio
import matplotlib.pylab as mpl
dt=imageio.imread('bird.png')
mpl.imshow(dt)
mpl.show()

#Xử lí ảnh bằng imread để biến ảnh thành array rồi ép array vô imshow để tạo ảnh