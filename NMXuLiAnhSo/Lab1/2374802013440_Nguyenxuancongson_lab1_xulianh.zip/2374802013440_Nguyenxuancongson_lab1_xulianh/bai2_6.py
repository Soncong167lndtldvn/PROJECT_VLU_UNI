import numpy as np
import imageio.v2 as img
import matplotlib.pylab as mpl
import colorsys
rbg=img.imread('bird.png')
rbg2hsv=np.vectorize(colorsys.rgb_to_hsv)
h,s,v=rbg2hsv(rbg[ :, :, 0], rbg[ :, :, 1], rbg[ :, :, 2])
h*=h
hsv2rbg=np.vectorize(colorsys.hsv_to_rgb)
rbg2=hsv2rbg(h,s,v)
rbg2=np.array(rbg2).transpose((1,2,0))
mpl.imshow(rbg2)
mpl.show()
