import numpy as np
import imageio.v2 as img
import matplotlib.pylab as mpl
dt=img.imread('bird.png')
dt_2=(dt[ :, :, 1]+dt[ :, :, 2])
mpl.imshow(dt_2)
mpl.show()