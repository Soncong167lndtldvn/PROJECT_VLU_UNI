from skimage import io
image = io.imread('bird.png')
swapped_image = image.copy()
swapped_image[:, :, 0] = image[:, :, 2]
swapped_image[:, :, 2] = image[:, :, 0]
io.imsave('swapped_colors.png', swapped_image)