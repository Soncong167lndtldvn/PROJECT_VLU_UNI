from skimage import io, color
import numpy as np
image = io.imread('bird.png')
red = image[:, :, 0]
green = image[:, :, 1]
blue = image[:, :, 2]
io.imsave('red_channel.png', red)
io.imsave('green_channel.png', green)
io.imsave('blue_channel.png', blue)