import numpy as np
import skimage.io
import skimage.color
import matplotlib.pylab as plt
data = skimage.io.imread('bird.png')
gray = skimage.color.rgb2gray(data)  # Kết quả là ảnh float trong khoảng [0, 1]
gray_uint8 = (gray * 255).astype(np.uint8)
cl = gray_uint8 & 0xF0
skimage.io.imsave('birdf0.png', cl)
tmp = skimage.io.imread('birdf0.png')
plt.imshow(tmp, cmap='gray')
plt.show()
