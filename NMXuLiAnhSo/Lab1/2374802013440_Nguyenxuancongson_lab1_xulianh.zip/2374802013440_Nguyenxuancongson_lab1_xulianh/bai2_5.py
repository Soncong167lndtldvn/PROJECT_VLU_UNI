import numpy as np
import imageio.v2 as img
import matplotlib.pylab as mpl
import colorsys
a=colorsys.rgb_to_hsv(255,0,0)
b=colorsys.rgb_to_hsv(1,0,0)
c=colorsys.rgb_to_hsv(0,255,0)
d=colorsys.rgb_to_hsv(1,1,255)
print(f"{a}\n{b}\n{c}\n{d}")
