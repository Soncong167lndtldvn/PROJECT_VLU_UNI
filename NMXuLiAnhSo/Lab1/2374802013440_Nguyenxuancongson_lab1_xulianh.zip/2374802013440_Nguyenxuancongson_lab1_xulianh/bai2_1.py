from PIL import Image
img=Image.open('bird.png')
img.show()

#Xử lí ảnh bằng PIL