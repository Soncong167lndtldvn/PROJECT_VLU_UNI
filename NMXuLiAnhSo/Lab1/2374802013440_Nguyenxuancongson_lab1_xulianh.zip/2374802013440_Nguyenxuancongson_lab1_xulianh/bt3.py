from skimage import io, color
import numpy as np
image = io.imread('bird.png')
hsv_image = color.rgb2hsv(image)
hue = (hsv_image[:, :, 0] * 255).astype(np.uint8) 
saturation = (hsv_image[:, :, 1] * 255).astype(np.uint8)
value = (hsv_image[:, :, 2] * 255).astype(np.uint8)
io.imsave('hue.png', hue)
io.imsave('saturation.png', saturation)
io.imsave('value.png', value)