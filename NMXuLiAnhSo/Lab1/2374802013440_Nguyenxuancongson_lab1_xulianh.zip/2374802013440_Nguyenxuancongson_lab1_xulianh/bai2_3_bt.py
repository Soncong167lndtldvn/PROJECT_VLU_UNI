import numpy as np
import skimage.io
import skimage.color
import matplotlib.pylab as plt
data = skimage.io.imread('bird.png')
gray = skimage.color.rgb2gray(data)  # Kết quả là ảnh float trong khoảng [0, 1]
gray_uint8 = (gray * 255).astype(np.uint8)
cl = gray_uint8 & 0xC0
skimage.io.imsave('birdc0.png', cl)
tmp = skimage.io.imread('birdc0.png')
plt.imshow(tmp, cmap='gray')
plt.show()

cl = gray_uint8 & 0x80
skimage.io.imsave('bird80.png', cl)
tmp = skimage.io.imread('bird80.png')
plt.imshow(tmp, cmap='gray')
plt.show()
